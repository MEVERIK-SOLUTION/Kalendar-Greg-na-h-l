'use client';
import { useState } from 'react';

function calculate(a, b) {
  // TODO: Replace with actual formula extracted from Excel
  return a * b;
}

export default function Home() {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  const result = calculate(Number(a), Number(b));

  return (
    <main style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>Excel Formula App</h1>
      <div style={{ marginBottom: 20 }}>
        <label>
          Input A:
          <input
            type="number"
            value={a}
            onChange={(e) => setA(e.target.value)}
            style={{ marginLeft: 10 }}
          />
        </label>
      </div>
      <div style={{ marginBottom: 20 }}>
        <label>
          Input B:
          <input
            type="number"
            value={b}
            onChange={(e) => setB(e.target.value)}
            style={{ marginLeft: 10 }}
          />
        </label>
      </div>
      <h2>Result: {result}</h2>
    </main>
  );
}