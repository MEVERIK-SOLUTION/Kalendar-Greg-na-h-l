# Excel Formula App

Simple Next.js app prepared for deploying on Vercel.

## Development

npm install
npm run dev

## Build

npm run build
npm start

Replace the `calculate` function in app/page.js with the extracted Excel formula logic.